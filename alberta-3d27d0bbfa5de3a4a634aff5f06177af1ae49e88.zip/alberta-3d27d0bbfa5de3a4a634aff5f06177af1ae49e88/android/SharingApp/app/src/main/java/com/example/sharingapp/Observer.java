package com.example.sharingapp;

/**
 * Observer Interface
 */
interface Observer {
    void update();
}
