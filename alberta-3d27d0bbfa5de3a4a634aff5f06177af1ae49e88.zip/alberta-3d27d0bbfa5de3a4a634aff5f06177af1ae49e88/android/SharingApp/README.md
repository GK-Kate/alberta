# SharingApp

Android application for the courses in the **Design and Software Architecture** specialization offered by **University of Alberta** on Coursera.

Courses:
* Object-Oriented Design
* Design Patterns
* Software Architecture
* Service-Oriented Architecture
